function changePrice() {
    document.getElementById("price").innerText = "İndirimli Fiyat: 35₺";
}

document.addEventListener("DOMContentLoaded", function () {
    const emailInput = document.getElementById("email");
    if (emailInput) {
        emailInput.addEventListener("input", function () {
            const regex = /^[^@]+@[^@]+\.[a-z]{2,}$/i;
            const feedback = document.getElementById("emailError");
            feedback.textContent = regex.test(this.value) ? "✓" : "Geçersiz e-posta";
            feedback.style.color = regex.test(this.value) ? "green" : "red";
        });
    }
});
